<?php
$servername = "localhost";//数据库地址
$username = "test_zsblog_org";//数据库账号
$password = "test_zsblog_org";//数据库密码
$dbname = "test_zsblog_org";//数据库名
?>